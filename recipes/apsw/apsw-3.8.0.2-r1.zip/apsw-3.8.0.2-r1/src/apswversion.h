#define APSW_VERSION "3.8.0.2-r1"
